// Service Worker for Neon Invaders PWA
const CACHE_NAME = 'neon-invaders-v1.0.0';
const RUNTIME_CACHE = 'neon-invaders-runtime-v1';

// Core app files to cache immediately
const PRECACHE_URLS = [
  './',
  './index.html',
  './manifest.json',
  './src/main.tsx',
  './src/App.tsx',
  './src/index.css'
];

// Game assets from S3 - will be cached on first use
const GAME_ASSETS = [
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/f3b62150-4a75-4f79-a287-beb738d7988f.webp', // player
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/95d93858-1da2-4410-bc6d-7c97a81a2690.webp', // alien basic
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/b6b8921b-cb05-4c7c-9637-17e8f8199206.webp', // alien heavy
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/0ee5fdad-b7fc-40b7-b71b-5785189cd229.webp', // alien fast
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/038a876a-d68c-4444-b8b0-2ae9ab25580c.webp', // boss
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/bf008940-7261-4765-8c6d-32086670999c.webp', // explosion
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/652b9540-094e-4c3a-b9b9-64f112b28744.webp', // powerup plasma
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/30aacb08-5108-4c70-8580-1823f93620ed.webp', // powerup rapid
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/c52e69ca-3469-4246-88ce-38a9fde77993.webp', // powerup shield
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/f825721c-8221-4dff-919b-1365add27ab7.webp', // powerup slowmo
  'https://newoaks.s3.us-west-1.amazonaws.com/AutoDev/30807/969a16ba-05c1-4406-8632-b5809c2e3b85.webp'  // shield effect
];

// Install event - cache core resources
self.addEventListener('install', (event) => {
  console.log('[SW] Installing service worker...');

  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Precaching core app files');
        return cache.addAll(PRECACHE_URLS);
      })
      .then(() => {
        console.log('[SW] Core files cached successfully');
        // Optionally precache game assets in background
        return caches.open(RUNTIME_CACHE).then((cache) => {
          return cache.addAll(GAME_ASSETS).catch((err) => {
            console.warn('[SW] Some game assets failed to precache:', err);
          });
        });
      })
      .catch((error) => {
        console.error('[SW] Cache installation failed:', error);
      })
  );

  // Force the waiting service worker to become the active service worker
  self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating service worker...');

  const cacheWhitelist = [CACHE_NAME, RUNTIME_CACHE];

  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (!cacheWhitelist.includes(cacheName)) {
            console.log('[SW] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('[SW] Service worker activated');
    })
  );

  // Take control of all pages immediately
  self.clients.claim();
});

// Fetch event - implement caching strategies
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }

  // Skip chrome-extension and other non-http(s) requests
  if (!url.protocol.startsWith('http')) {
    return;
  }

  // Strategy 1: Cache First for game assets (images, fonts, etc.)
  if (isGameAsset(url)) {
    event.respondWith(cacheFirst(request));
    return;
  }

  // Strategy 2: Network First for HTML/API calls
  if (isHTMLRequest(request) || isAPIRequest(url)) {
    event.respondWith(networkFirst(request));
    return;
  }

  // Strategy 3: Stale While Revalidate for other resources
  event.respondWith(staleWhileRevalidate(request));
});

// Cache First Strategy - best for static assets
async function cacheFirst(request) {
  const cache = await caches.open(RUNTIME_CACHE);
  const cached = await cache.match(request);

  if (cached) {
    return cached;
  }

  try {
    const response = await fetch(request);
    if (response.ok) {
      cache.put(request, response.clone());
    }
    return response;
  } catch (error) {
    console.error('[SW] Cache First fetch failed:', error);
    return offlineResponse();
  }
}

// Network First Strategy - best for dynamic content
async function networkFirst(request) {
  const cache = await caches.open(RUNTIME_CACHE);

  try {
    const response = await fetch(request);
    if (response.ok) {
      cache.put(request, response.clone());
    }
    return response;
  } catch (error) {
    const cached = await cache.match(request);
    if (cached) {
      return cached;
    }

    // Return offline page for HTML requests
    if (isHTMLRequest(request)) {
      return offlineResponse();
    }

    throw error;
  }
}

// Stale While Revalidate - best for frequently updated resources
async function staleWhileRevalidate(request) {
  const cache = await caches.open(RUNTIME_CACHE);
  const cached = await cache.match(request);

  const fetchPromise = fetch(request).then((response) => {
    if (response.ok) {
      cache.put(request, response.clone());
    }
    return response;
  }).catch(() => cached);

  return cached || fetchPromise;
}

// Helper functions
function isGameAsset(url) {
  return url.hostname === 'newoaks.s3.us-west-1.amazonaws.com' ||
         url.pathname.match(/\.(png|jpg|jpeg|svg|gif|webp|woff|woff2|ttf|eot)$/);
}

function isHTMLRequest(request) {
  return request.headers.get('accept')?.includes('text/html');
}

function isAPIRequest(url) {
  return url.pathname.startsWith('/api/') || url.hostname.includes('api.');
}

function offlineResponse() {
  return new Response(
    `<!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Neon Invaders - Offline</title>
      <style>
        body {
          margin: 0;
          padding: 0;
          font-family: 'Courier New', monospace;
          background: linear-gradient(135deg, #0a0014 0%, #0d001a 50%, #150028 100%);
          color: #22d3ee;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          height: 100vh;
          text-align: center;
        }
        h1 {
          font-size: 3em;
          background: linear-gradient(180deg, #22d3ee 0%, #3b82f6 50%, #ec4899 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        p { font-size: 1.2em; margin: 20px; }
        .emoji { font-size: 4em; margin: 20px; }
        button {
          padding: 15px 30px;
          font-size: 1.2em;
          background: transparent;
          border: 2px solid #22d3ee;
          color: #22d3ee;
          border-radius: 8px;
          cursor: pointer;
          margin-top: 20px;
        }
        button:hover { background: #22d3ee; color: #0a0014; }
      </style>
    </head>
    <body>
      <div class="emoji">📡</div>
      <h1>YOU'RE OFFLINE</h1>
      <p>Unable to connect to the network.</p>
      <p>Neon Invaders is cached and ready to play!</p>
      <button onclick="window.location.href='/'">Return to Game</button>
    </body>
    </html>`,
    {
      status: 200,
      statusText: 'OK',
      headers: new Headers({
        'Content-Type': 'text/html'
      })
    }
  );
}

// Handle messages from clients
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data && event.data.type === 'CACHE_ASSETS') {
    event.waitUntil(
      caches.open(RUNTIME_CACHE).then((cache) => {
        return cache.addAll(GAME_ASSETS);
      })
    );
  }

  if (event.data && event.data.type === 'CLEAR_CACHE') {
    event.waitUntil(
      caches.keys().then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => caches.delete(cacheName))
        );
      })
    );
  }
});

// Background sync for offline score submission
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-high-scores') {
    event.waitUntil(syncHighScores());
  }
});

async function syncHighScores() {
  console.log('[SW] Syncing high scores...');
  // Get scores from IndexedDB and sync to server
  // Implementation depends on your backend
  try {
    // Placeholder for actual sync logic
    const scores = await getStoredScores();
    if (scores && scores.length > 0) {
      // await fetch('/api/scores', { method: 'POST', body: JSON.stringify(scores) });
      console.log('[SW] Scores synced successfully');
    }
  } catch (error) {
    console.error('[SW] Score sync failed:', error);
    throw error; // Retry on failure
  }
}

async function getStoredScores() {
  // Placeholder - implement IndexedDB retrieval
  return [];
}

// Push notification support
self.addEventListener('push', (event) => {
  const data = event.data ? event.data.json() : {};
  const options = {
    body: data.body || 'New challenge available!',
    icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192"><rect fill="%230a0014" width="192" height="192"/><text x="96" y="140" font-size="100" text-anchor="middle" fill="%2322d3ee">👾</text></svg>',
    badge: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect fill="%230a0014" width="96" height="96"/><text x="48" y="70" font-size="60" text-anchor="middle" fill="%2322d3ee">👾</text></svg>',
    vibrate: [200, 100, 200],
    tag: 'neon-invaders-notification',
    requireInteraction: false,
    data: {
      dateOfArrival: Date.now(),
      url: data.url || './index.html'
    },
    actions: [
      { action: 'play', title: 'Play Now' },
      { action: 'close', title: 'Dismiss' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Neon Invaders', options)
  );
});

// Notification click handler
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const url = event.notification.data?.url || './index.html';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((windowClients) => {
        // Check if there's already a window open
        for (let client of windowClients) {
          if (client.url === url && 'focus' in client) {
            return client.focus();
          }
        }
        // Open new window if none exists
        if (clients.openWindow) {
          return clients.openWindow(url);
        }
      })
  );
});

console.log('[SW] Service Worker loaded');
